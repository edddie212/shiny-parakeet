import Head from 'next/head';

const Meta = ({title, description, author, keywords})=>{
  return (
      <Head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'></meta>
        <meta name='description' content={description}></meta>
        <meta name='keywords' content={keywords}></meta>
        <meta name='author' content={author}></meta>
        <title>{title}</title>
      </Head>
  );
}
Meta.defaultProps = {
    title: 'WebDev NextJS Crash Course',
    description: 'Learning next.js with traversy media on youtube',
    author: 'Traversy Media',
    keywords: 'Next.js, javascript, web development',
};

export default Meta