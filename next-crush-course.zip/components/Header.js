import stylesHeader from '../styles/Header.module.css';

const Header = (()=>{
 return (
     <div>
         <h1 className={stylesHeader.title}>
             <span>Webdev Next</span>JS Crush Course
             </h1>
             <p>Learn next.js with Traversy Media best crush course.</p>         
     </div>
 )
});

export default Header;