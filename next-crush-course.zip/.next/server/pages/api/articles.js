"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/articles";
exports.ids = ["pages/api/articles"];
exports.modules = {

/***/ "./data.js":
/*!*****************!*\
  !*** ./data.js ***!
  \*****************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"articles\": () => (/* binding */ articles)\n/* harmony export */ });\nconst articles = [\n    {\n        id: '1',\n        title: 'GitHub introduces dark mode and auto-merge pull request',\n        excerpt: 'GitHub today announced a bunch of new features at its virtual GitHub...',\n        body: 'GitHub today announced a bunch of new features at its virtual GitHub Universe conference including dark mode, auto-merge pull requests, and Enterprise Server 3.0. In the past couple of years, almost all major apps have rolled out a dark theme for its users, so why not GitHub?'\n    },\n    {\n        id: '2',\n        title: 'What’s multi-cloud? And why should developers care?',\n        excerpt: 'Most developers don’t care about multi-cloud. But they should...',\n        body: 'Most developers don’t care about multi-cloud. But they should. Whether developers know it or not, their companies likely already have a multi-cloud environment.    Multi-cloud is a strategy where a business selects different services from different cloud providers'\n    },\n    {\n        id: '3',\n        title: 'Here is how to make your website more accessible',\n        excerpt: 'An accessible website is one that’s optimized for all people, including those with disabilities...',\n        body: 'There are many things to consider when setting up a website, and accessibility is one factor that can sometimes be overlooked. An accessible website is one that’s optimized for all people, including those with impaired vision or hearing, motor difficulties, or learning disabilities'\n    },\n    {\n        id: '4',\n        title: 'Why open ecosystems are the future of app development',\n        excerpt: 'When app stores entered the mainstream tech culture, they exposed developers to an audience of millions...',\n        body: 'We can’t get enough of our mobile apps. There were 204 billion apps downloads last year, and that number is rising in 2020.  When app stores entered the mainstream tech culture, they exposed developers to an audience of millions who were keen to adopt the innovative capabilities'\n    }, \n];\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kYXRhLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBTyxLQUFLLENBQUNBLFFBQVEsR0FBRyxDQUFDO0lBQ3JCLENBQUM7UUFDQ0MsRUFBRSxFQUFFLENBQUc7UUFDUEMsS0FBSyxFQUFFLENBQXlEO1FBQ2hFQyxPQUFPLEVBQ0wsQ0FBeUU7UUFDM0VDLElBQUksRUFDRixDQUFzUjtJQUMxUixDQUFDO0lBQ0QsQ0FBQztRQUNDSCxFQUFFLEVBQUUsQ0FBRztRQUNQQyxLQUFLLEVBQUUsQ0FBcUQ7UUFDMURDLE9BQUssRUFBRSxDQUFrRTtRQUN6RUMsSUFBRSxFQUNGLENBQTBRO0lBQzVRLENBQUQ7SUFDRCxDQUFDO1FBQ0NILEVBQUUsRUFBRSxDQUFHO1FBQ1BDLEtBQUssRUFBRSxDQUFrRDtRQUN6REMsT0FBTyxFQUNMLENBQW9HO1FBQ3BHQyxJQUFFLEVBQ0YsQ0FBNFI7SUFDOVIsQ0FBRDtJQUNELENBQUM7UUFDQ0gsRUFBRSxFQUFFLENBQUc7UUFDUEMsS0FBSyxFQUFFLENBQXVEO1FBQzlEQyxPQUFPLEVBQ0wsQ0FBNEc7UUFDOUdDLElBQUksRUFDRixDQUF5UjtJQUM3UixDQUFDO0FBQ0gsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtY3J1c2gtY291cnNlLy4vZGF0YS5qcz81MTFlIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBhcnRpY2xlcyA9IFtcclxuICAgIHtcclxuICAgICAgaWQ6ICcxJyxcclxuICAgICAgdGl0bGU6ICdHaXRIdWIgaW50cm9kdWNlcyBkYXJrIG1vZGUgYW5kIGF1dG8tbWVyZ2UgcHVsbCByZXF1ZXN0JyxcclxuICAgICAgZXhjZXJwdDpcclxuICAgICAgICAnR2l0SHViIHRvZGF5IGFubm91bmNlZCBhIGJ1bmNoIG9mIG5ldyBmZWF0dXJlcyBhdCBpdHMgdmlydHVhbCBHaXRIdWIuLi4nLFxyXG4gICAgICBib2R5OlxyXG4gICAgICAgICdHaXRIdWIgdG9kYXkgYW5ub3VuY2VkIGEgYnVuY2ggb2YgbmV3IGZlYXR1cmVzIGF0IGl0cyB2aXJ0dWFsIEdpdEh1YiBVbml2ZXJzZSBjb25mZXJlbmNlIGluY2x1ZGluZyBkYXJrIG1vZGUsIGF1dG8tbWVyZ2UgcHVsbCByZXF1ZXN0cywgYW5kIEVudGVycHJpc2UgU2VydmVyIDMuMC4gSW4gdGhlIHBhc3QgY291cGxlIG9mIHllYXJzLCBhbG1vc3QgYWxsIG1ham9yIGFwcHMgaGF2ZSByb2xsZWQgb3V0IGEgZGFyayB0aGVtZSBmb3IgaXRzIHVzZXJzLCBzbyB3aHkgbm90IEdpdEh1Yj8nLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICcyJyxcclxuICAgICAgdGl0bGU6ICdXaGF04oCZcyBtdWx0aS1jbG91ZD8gQW5kIHdoeSBzaG91bGQgZGV2ZWxvcGVycyBjYXJlPycsXHJcbiAgICAgIGV4Y2VycHQ6ICdNb3N0IGRldmVsb3BlcnMgZG9u4oCZdCBjYXJlIGFib3V0IG11bHRpLWNsb3VkLiBCdXQgdGhleSBzaG91bGQuLi4nLFxyXG4gICAgICBib2R5OlxyXG4gICAgICAgICdNb3N0IGRldmVsb3BlcnMgZG9u4oCZdCBjYXJlIGFib3V0IG11bHRpLWNsb3VkLiBCdXQgdGhleSBzaG91bGQuIFdoZXRoZXIgZGV2ZWxvcGVycyBrbm93IGl0IG9yIG5vdCwgdGhlaXIgY29tcGFuaWVzIGxpa2VseSBhbHJlYWR5IGhhdmUgYSBtdWx0aS1jbG91ZCBlbnZpcm9ubWVudC4gICAgTXVsdGktY2xvdWQgaXMgYSBzdHJhdGVneSB3aGVyZSBhIGJ1c2luZXNzIHNlbGVjdHMgZGlmZmVyZW50IHNlcnZpY2VzIGZyb20gZGlmZmVyZW50IGNsb3VkIHByb3ZpZGVycycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogJzMnLFxyXG4gICAgICB0aXRsZTogJ0hlcmUgaXMgaG93IHRvIG1ha2UgeW91ciB3ZWJzaXRlIG1vcmUgYWNjZXNzaWJsZScsXHJcbiAgICAgIGV4Y2VycHQ6XHJcbiAgICAgICAgJ0FuIGFjY2Vzc2libGUgd2Vic2l0ZSBpcyBvbmUgdGhhdOKAmXMgb3B0aW1pemVkIGZvciBhbGwgcGVvcGxlLCBpbmNsdWRpbmcgdGhvc2Ugd2l0aCBkaXNhYmlsaXRpZXMuLi4nLFxyXG4gICAgICBib2R5OlxyXG4gICAgICAgICdUaGVyZSBhcmUgbWFueSB0aGluZ3MgdG8gY29uc2lkZXIgd2hlbiBzZXR0aW5nIHVwIGEgd2Vic2l0ZSwgYW5kIGFjY2Vzc2liaWxpdHkgaXMgb25lIGZhY3RvciB0aGF0IGNhbiBzb21ldGltZXMgYmUgb3Zlcmxvb2tlZC4gQW4gYWNjZXNzaWJsZSB3ZWJzaXRlIGlzIG9uZSB0aGF04oCZcyBvcHRpbWl6ZWQgZm9yIGFsbCBwZW9wbGUsIGluY2x1ZGluZyB0aG9zZSB3aXRoIGltcGFpcmVkIHZpc2lvbiBvciBoZWFyaW5nLCBtb3RvciBkaWZmaWN1bHRpZXMsIG9yIGxlYXJuaW5nIGRpc2FiaWxpdGllcycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogJzQnLFxyXG4gICAgICB0aXRsZTogJ1doeSBvcGVuIGVjb3N5c3RlbXMgYXJlIHRoZSBmdXR1cmUgb2YgYXBwIGRldmVsb3BtZW50JyxcclxuICAgICAgZXhjZXJwdDpcclxuICAgICAgICAnV2hlbiBhcHAgc3RvcmVzIGVudGVyZWQgdGhlIG1haW5zdHJlYW0gdGVjaCBjdWx0dXJlLCB0aGV5IGV4cG9zZWQgZGV2ZWxvcGVycyB0byBhbiBhdWRpZW5jZSBvZiBtaWxsaW9ucy4uLicsXHJcbiAgICAgIGJvZHk6XHJcbiAgICAgICAgJ1dlIGNhbuKAmXQgZ2V0IGVub3VnaCBvZiBvdXIgbW9iaWxlIGFwcHMuIFRoZXJlIHdlcmUgMjA0IGJpbGxpb24gYXBwcyBkb3dubG9hZHMgbGFzdCB5ZWFyLCBhbmQgdGhhdCBudW1iZXIgaXMgcmlzaW5nIGluIDIwMjAuICBXaGVuIGFwcCBzdG9yZXMgZW50ZXJlZCB0aGUgbWFpbnN0cmVhbSB0ZWNoIGN1bHR1cmUsIHRoZXkgZXhwb3NlZCBkZXZlbG9wZXJzIHRvIGFuIGF1ZGllbmNlIG9mIG1pbGxpb25zIHdobyB3ZXJlIGtlZW4gdG8gYWRvcHQgdGhlIGlubm92YXRpdmUgY2FwYWJpbGl0aWVzJyxcclxuICAgIH0sXHJcbiAgXSJdLCJuYW1lcyI6WyJhcnRpY2xlcyIsImlkIiwidGl0bGUiLCJleGNlcnB0IiwiYm9keSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./data.js\n");

/***/ }),

/***/ "./pages/api/articles/index.js":
/*!*************************************!*\
  !*** ./pages/api/articles/index.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../data */ \"./data.js\");\n\nfunction handler(req, res) {\n    res.status(200).json(_data__WEBPACK_IMPORTED_MODULE_0__.articles);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hcGkvYXJ0aWNsZXMvaW5kZXguanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBc0M7QUFFdkIsUUFBUSxDQUFDQyxPQUFPLENBQUVDLEdBQUcsRUFBRUMsR0FBRyxFQUFFLENBQUM7SUFDMUNBLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDLEdBQUcsRUFBRUMsSUFBSSxDQUFDTCwyQ0FBUTtBQUMvQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1jcnVzaC1jb3Vyc2UvLi9wYWdlcy9hcGkvYXJ0aWNsZXMvaW5kZXguanM/ZDgzNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2FydGljbGVzfSBmcm9tICcuLi8uLi8uLi9kYXRhJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIgKHJlcSwgcmVzKSB7IFxyXG4gIHJlcy5zdGF0dXMoMjAwKS5qc29uKGFydGljbGVzKSA7XHJcbn1cclxuIl0sIm5hbWVzIjpbImFydGljbGVzIiwiaGFuZGxlciIsInJlcSIsInJlcyIsInN0YXR1cyIsImpzb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/api/articles/index.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/articles/index.js"));
module.exports = __webpack_exports__;

})();