import style from './Searchbox.module.css';

const SearchBox = ({ ...props }) => {
  return (
    <div className={style.search_box}>
      <input {...props} />
    </div>
  );
};

export default SearchBox;
